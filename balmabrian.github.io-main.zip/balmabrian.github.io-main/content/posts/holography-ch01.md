---
title: "Holography Ch01"
date: 2022-09-24T02:21:01-07:00
publishDate: 2022-09-24T02:21:01-07:00
---

# Holography, My new Film Infactuation

Holograms are very much a fantasied technology in science fiction. When I was younger, I remember buying dolar store stickers where the image apreared 3D at diffrent angles. Now a days, holograms are no longer a science fiction, but a reality. New age Holograms are a very interesting technology, and I am very interested in learning more about them but first, I need to learn about the orginal hologram since the concept has been around since the 40's.

## History of Holography

<iframe src="https://player.vimeo.com/video/74477582?h=15fd51b15d" width="640" height="360" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen></iframe>
<p><a href="https://vimeo.com/74477582">GIZMODO - The History of Holograms</a> from <a href="https://vimeo.com/gizmodo">Gizmodo</a> on <a href="https://vimeo.com">Vimeo</a>.</p>