---
title: "$ whoami"
---

# About

I am a Computer Science University Student. I am currently working on my Bachelor's Degree in Computer Science at California State University, Sacramento. Currently I am working on my senior project, which is a application for the Biology department at Sacramento State. 

---

## Projects

### My school projects are:
- [CSC 199 project](/reports/CSC-199-Report-AR-VR-Lab.pdf)
- [CSC 131 project](https://github.com/BalmaBrian/csc-131---team-ludus-916)
- [Learning Git Lab](https://github.com/BalmaBrian/git-started)

### My club projects are:
- [Rocket Engine Server in Python](https://github.com/LiquidPropulsionGroup/EnginePythonServer)
- [Rocket Engine Server in Express](https://github.com/LiquidPropulsionGroup/EngineWebServer)
- [TUI for LPG](https://github.com/BalmaBrian/lpg-tui)
- [CLI for LPG](https://github.com/BalmaBrian/lpg-rocket-cli)

### My hackathon projects are:
- [Reading Rainbows](https://github.com/Team-Monogram/Reading-Rainbow)
- [Moody Tweets](https://github.com/BalmaBrian/MoodyTweets)
- [Stamper](https://github.com/BalmaBrian/Stamper)
- [Lift Assist](https://devpost.com/software/lift-assist)

### My work projects are:
- [GenCyber RnD Organization](https://github.com/CSUS-GenCyber-RnD)

### My personal projects are:
- [AutoMagic Script repo](https://github.com/BalmaBrian/automagic)
- [bonap-spider](https://github.com/BalmaBrian/bonap-datasets)