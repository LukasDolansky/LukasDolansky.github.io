---
title: "CSC 173 Assignment 1"
date: 2022-09-27T22:32:18-07:00
---

# CSC 173 Assignment 1

This is the first visulization I came up with for my CSC 173 class. We were given a ton of data on the DFW rates for all the courses at Sac State. I was tasked with finding a way to visualize the data in a way that would be useful to the Sac State community.

The question I was trying to answer was: 
- "What are the diffrent DFW rates for a students major as the course increases from lower to upper division?"

The problem I was trying to solve was: 
- "Students are not aware of all, but some, of the courses that are hard and have a high DFW rate."

Below are some of the reports I created for the NSM, ECS, and A&S colleges at sac state:

### Natral Science and Mathmatics College
<iframe src="/reports/DFW for Natral Science and Mathmatics College.html" width="100%" height="750px"></iframe>

### Engineering and Computer Science College
<iframe src="/reports/DFW for Engineering College.html" width="100%" height="750px"></iframe>

### Arts and Letters College
<iframe src="/reports/DFW for Arts and Letters College.html" width="100%" height="750px"></iframe>